package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.User;

public class AccountRegisterDAO {
    private String name = "";
    private String pass = "";

    public AccountRegisterDAO(User abc) {

        // TODO 自動生成されたコンストラクター・スタブ

        this.name = abc.getName();
        this.pass = abc.getPass();

    }

    public String getName() {
        return name;
    }

    public String getPass() {
        return pass;
    }

    // 新規登録のDAO

    private final String JDBC_URL = "Jdbc:mysql://172.16.61.117:3306/book_lover";
    private final String DB_USER = "unic01";
    private final String DB_PASS = "unic01pass";

    public boolean newAccount(User abc) {
        // User returnAb = new User();
        boolean check = false;
        int r = 0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }
        try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
            String sql = "INSERT INTO login (id,name,pass)VALUES(0,?,?)";
            PreparedStatement pStmt = conn.prepareStatement(sql);

            pStmt.setString(1, name);
            pStmt.setString(2, pass);

            conn.setAutoCommit(false);
            r = pStmt.executeUpdate();
            conn.commit();

            if (r != 0) {
                check = true;

            } else {
                check = false;
                // 登録失敗 フォワード
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return check;
    }

}
