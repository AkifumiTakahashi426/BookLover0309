package model;

public class LoginLogic {
    public boolean execute(User user) {
        return false;



//        if(user.getName()=""&&user.getPass().equals("1234")) {//""にDBとの照合処理を記述
//            return true;
//        }
//        return false;
   }

}