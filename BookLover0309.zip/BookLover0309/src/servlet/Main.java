package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.Book;
import dao.AccountDAO;
import dao.AccountRegisterDAO;
import dao.BookLoverDAO;
import model.User;

/**
 * Servlet implementation class Main
 */
@WebServlet("/Main")
public class Main extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Main() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        // response.getWriter().append("Served at: ").append(request.getContextPath());
        String forwardPath = "";
        request.setCharacterEncoding("utf-8");
        String menu = request.getParameter("menu");
        HttpSession session = request.getSession();

        switch (menu) {

        case "1"://登録画面へ
            forwardPath = "/WEB-INF/jsp/register.jsp";
            session.removeAttribute("bookList");
            break;

        case "2"://持ってる本(Management)画面へ
            session.removeAttribute("bookList");
            String id = (String) session.getAttribute("id");
            BookLoverDAO bk = new BookLoverDAO();
            List<Book> bookList = bk.findHaveDAO(id);
            session.setAttribute("bookList", bookList);
            forwardPath = "/WEB-INF/jsp/management.jsp";
            break;

        case "3"://お気に入り一覧へ
            String id1 = (String) session.getAttribute("id");
            BookLoverDAO bk1 = new BookLoverDAO();
            List<Book> bookList1 = bk1.findWantDAO(id1);
            session.setAttribute("bookList", bookList1);
            forwardPath = "/WEB-INF/jsp/want.jsp";
            break;

        case "4"://新規登録画面へ
            forwardPath = "/WEB-INF/jsp/newUser.jsp";
            break;

        case "5":// ログアウト
            session.invalidate();
            forwardPath = "/";
            break;

        case "10":// 内緒
            forwardPath = "/WEB-INF/jsp/top.jsp";
        default:

        }
        RequestDispatcher dispatcher = request.getRequestDispatcher(forwardPath);
        dispatcher.forward(request, response);

    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        // doGet(request, response);
        String forwardPath = "";
        request.setCharacterEncoding("utf-8");
        String menu = request.getParameter("menu");
        String userName;
        String pass;
        String id;

        switch (menu) {
        case "1":
            // ログイン処理

            // 入力されたnameとパスワードを取得
            userName = request.getParameter("userName");
            pass = request.getParameter("pass");

            User ab = new User();
            //
            ab.setName(userName);
            ab.setPass(pass);
            AccountDAO ad = new AccountDAO();
            User returnAb = ad.findAccount(ab);
            id = ad.findId(ab);
            if (returnAb != null) {
                HttpSession session = request.getSession();
                session.setAttribute("account", returnAb);
                // フォワード先(成功)
                forwardPath = "/WEB-INF/jsp/top.jsp";
                /// idとuserNameをスコープへ保存
                session.setAttribute("id", id);
                session.setAttribute("userName", userName);

            } else {
                // 失敗
                forwardPath = "/WEB-INF/jsp/loginError.jsp";
            }

            break;
        case "2":
            // 新規登録
            userName = request.getParameter("userName");
            String newPass = request.getParameter("newPass");
            // jspから受けっとった値をBeans(User)にセット
            User abc = new User();
            abc.setName(userName);
            abc.setPass(newPass);

            AccountRegisterDAO ard = new AccountRegisterDAO(abc);
            HttpSession session = request.getSession();
            // userNameとuserPassをスコープに保存
            session.setAttribute("userName", userName);
            session.setAttribute("newPass", newPass);
            boolean check = ard.newAccount(abc);
            // checkの中にtrueが入っていれば登録成功画面へ
            if (check == true) {
                forwardPath = "/WEB-INF/jsp/completion.jsp";

            } else {
                forwardPath = "/WEB-INF/jsp/loginError.jsp";
            }

            break;
        case "3":
        default:

        }
        RequestDispatcher dispatcher = request.getRequestDispatcher(forwardPath);
        dispatcher.forward(request, response);
    }

}