package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.Book;
import dao.BookLoverDAO;

@WebServlet("/Management")
public class Management extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Management() {
        super();
        // TODO Auto-generated constructor

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // セッション作成
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();

        // ユーザーid取得
        String id = (String) session.getAttribute("id");

        // 画面遷移後に表示するメッセージ
        String msg = null;

        // JSPページを呼び出すためのRequestDispatcher
        RequestDispatcher dispatcher = null;
        String forwardPath = "/WEB-INF/jsp/error.jsp";

        String action = request.getParameter("action");
        String identifier = request.getParameter("identifier");
        String title = request.getParameter("title");
        String selfLink = request.getParameter("selfLink");


        List<Book> bookList = new ArrayList<Book>();
        Book book = null;
        boolean done = false;

        BookLoverDAO blDAO = new BookLoverDAO();

        bookList = blDAO.findHaveDAO(id);
        session.setAttribute("bookList", bookList);

        switch (action) {
        case "search":// 検索の時

            // identifierが入力されていたらidentifierで検索
            if (identifier != null && identifier.length() > 0) {
                bookList = blDAO.informationSearchDAO(id, identifier);

                // identifierが無ければタイトルで検索
            } else if (title != null && title.length() > 0) {
                bookList = blDAO.findTitleDAO(id, title);
            } else {// 入力が無ければ
                msg = "入力がありませんでした";

            }

            // 一つも見つからなければ
            if (bookList.size() <= 0) {
                msg = "検索結果が見つかりませんでした";
            }

            // セッションスコープに格納
            session.setAttribute("bookList", bookList);

            // フォワード先の指定
            forwardPath = "/WEB-INF/jsp/management.jsp";

            break;

        case "edit":// 編集画面に遷移
            System.out.println("edit");
            System.out.println("selfLinkの値："+selfLink);
            book = blDAO.informationDAO(id, selfLink);

            if(book==null) {
                System.out.println("bookがnullだよ");
            }

            request.setAttribute("book", book);
            forwardPath = "/WEB-INF/jsp/edit.jsp";
            break;

        case "delete":// 削除
            done = blDAO.deleteDAO(id, identifier);

            if (done) {
                msg = "正常に削除しました。";
                session.removeAttribute("bookList");

                bookList = blDAO.findHaveDAO(id);
                session.setAttribute("bookList", bookList);

                forwardPath = "/WEB-INF/jsp/management.jsp";

            } else {
                msg = "エラーが発生しました。";
                System.out.println("Managementサーブレットのdelete失敗");// test
            }
            break;

        case "update":// 更新
            int fun = Integer.parseInt(request.getParameter("fun"));
            String alReadyReadS = request.getParameter("alReadyRead");

            // Stringで取得するalreadyReadをパワープレイでbooleanに変換
            boolean alreadyRead = false;
            if (alReadyReadS.equals("true")) {
                alreadyRead = true;
            } else if (alReadyReadS.equals("false")) {
                alreadyRead = false;
            }
            String summary = request.getParameter("summary");
            done = blDAO.updateDAO(id, identifier, fun, alreadyRead, summary);

            if (done) {
                forwardPath = "/WEB-INF/jsp/management.jsp";
            } else {
                msg = "編集に誤りがあります。";
                System.out.println("Managementサーブレットのupdate失敗");// test
            }
            request.setAttribute("msg", msg);

            break;
        default:
            // NOT REACHED
        }
        // フォワード先へフォワードする
        dispatcher = request.getRequestDispatcher(forwardPath);
        dispatcher.forward(request, response);

    }

}
