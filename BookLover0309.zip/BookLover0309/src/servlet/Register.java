package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.Book;
import dao.BookLoverDAO;
import model.SearchBooks;

/**
 * Servlet implementation class Control
 */
@WebServlet("/Register")
public class Register extends HttpServlet implements EnvSet {
    private static final long serialVersionUID = 1L;

    public Register() {
        super();
        // TOD Auto-generated constructor stub
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // JSPページを呼び出すためのRequestDispatcher
        RequestDispatcher dispatcher = null;
        String forwardPath = "/WEB-INF/jsp/error.jsp";

        // セッション作成
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();

        // ユーザーid取得

        String id = (String) session.getAttribute("id");

        // 何列目のレコードが押されたか
        int record = -1;
        String action = request.getParameter("action");
        String identifier = request.getParameter("identifier");

        //文字列取得の際、スペースキーを+に変換し絞り込み検索のUI向上
        String title = request.getParameter("title");




        List<Book> bookList = new ArrayList<Book>();
        Book book = null;
        boolean done = false;

        // フォワードした時に出すメッセージを記入する変数
        String msg = "";

        // 書籍検索用モデルのインスタンス生成
        SearchBooks searchBooks = new SearchBooks();

        // DAO使用準備
        BookLoverDAO blDAO = new BookLoverDAO();

        // actionの文字列により分岐。
        switch (action) {
        case "search"://検索

            //検索文字列の変換
            title=title.replace(" ","+");
            title=title.replace("　","+");

            //セッションスコープからbookList削除
            session.removeAttribute("bookList");

            if (identifier.equals("") && title.equals("")) {// 何も入力されなかったら
                session.removeAttribute("bookList");
                msg = "情報が入力されていません。";

            } else {// isbnかタイトルが入力されていたら

                try {
                    // 書籍検索機能呼び出し、結果を配列に格納
                    bookList = searchBooks.searchBooks(id, identifier, title);

                    // disp.jspへ渡すデータを格納
                    session.setAttribute("bookList", bookList);

                } catch (Exception e) {
                    // 例外発生時、error.jspへフォワードする
                    request.setAttribute("error", e.toString());
                    forwardPath = "/WEB-INF/jsp/error.jsp";

                }

                if (bookList.size() < 1) {
                    msg = "検索結果は0件です。";
                } else if (bookList.size() >= 10) {
                    msg = "検索結果が10件以上取得されました。<br><br>お求めの書籍が表示されていないときは、検索ワードを追加するかISBNで検索してください。<br>";
                }
            }
            // 成功ならフォワード先を結果表示のjspに設定
            forwardPath = "/WEB-INF/jsp/register.jsp";
            break;


        case "buy"://登録

            record = Integer.parseInt(request.getParameter("record"));

            bookList = (List<Book>) session.getAttribute("bookList");
            Book buyBook = bookList.get(record);

            done = blDAO.newBuyDAO(id, buyBook);

            if (done) {
                msg = "購入一覧に追加しました。";

            } else {
                msg = "エラーが発生しました。";
                System.out.println("Managementサーブレットのdelete失敗");// test
            }
            request.setAttribute("msg", msg);
            forwardPath = "/WEB-INF/jsp/register.jsp";

            break;



        case "want"://お気に入りに追加

            record = Integer.parseInt(request.getParameter("record"));

            bookList = (List<Book>) session.getAttribute("bookList");
            Book wantBook = bookList.get(record);

            done = blDAO.newWantDAO(id, wantBook);

            if (done) {
                msg = "お気に入り一覧に追加しました。";

            } else {
                msg = "エラーが発生しました。(Registerサーブレット、お気に入り登録にて)";
            }
            request.setAttribute("msg", msg);
            forwardPath = "/WEB-INF/jsp/register.jsp";

            break;

        default:
            // NOT REACHED
        }

        request.setAttribute("msg", msg);

        // フォワード先へフォワードする
        dispatcher = request.getRequestDispatcher(forwardPath);
        dispatcher.forward(request, response);
    }

}
