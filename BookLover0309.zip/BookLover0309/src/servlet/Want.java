package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.Book;
import dao.BookLoverDAO;

/**
 * Servlet implementation class Want
 */
@WebServlet("/Want")
public class Want extends HttpServlet {
    private static final long serialVersionUID = 1L;


    public Want() {
        super();
        // TODO Auto-generated constructor stub
    }


    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        // response.getWriter().append("Served at: ").append(request.getContextPath());

    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        // doGet(request, response);

        RequestDispatcher dispatcher = null;
        String forwardPath = "";
        // セッションの作成
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();
        // ユーザーID取得
        String id = (String) session.getAttribute("id");
        String action = request.getParameter("action");
        String identifier = request.getParameter("identifier");
        boolean done=false;
        List<Book> myList;

        BookLoverDAO bl = new BookLoverDAO();
        switch (action) {
        case "delete":
            done = bl.deleteDAO(id, identifier);
            if (done) {

                // スコープ内の情報を更新

//                System.out.println("チェック1：myList.size()："+myList.size());

                session.removeAttribute("bookList");
                myList = bl.findWantDAO(id);

                System.out.println("チェック2：myList.size()："+myList.size());

                session.setAttribute("bookList", myList);
                forwardPath = "/WEB-INF/jsp/want.jsp";


            }else {
                //失敗ならエラーページへ推移
                forwardPath = "/WEB-INF/jsp/error.jsp";
            }
            break;

        case "buy":
            done = bl.buyDAO(id, identifier);
            if (done) {
                // スコープ内の情報を更新
                session.removeAttribute("bookList");
                myList = bl.findWantDAO(id);
                session.setAttribute("bookList", myList);
                forwardPath = "/WEB-INF/jsp/want.jsp";
            }else {
              //失敗ならエラーページへ推移
                forwardPath = "/WEB-INF/jsp/error.jsp";
            }
            break;
        default:

        }
        dispatcher = request.getRequestDispatcher(forwardPath);
        dispatcher.forward(request, response);
    }

}
