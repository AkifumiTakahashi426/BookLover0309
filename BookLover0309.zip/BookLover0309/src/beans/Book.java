package beans;

import java.io.Serializable;

public class Book implements Serializable {

    // id個人識別用
    private String id;

    // title書籍名
    private String title;

    // publisher出版社
    private String publisher;

    // authors著者
    private String authors;

    // thumbnail
    private String thumbnail;

    // ISBN
    private String identifier;

    // price（無い可能性ありのため無し？）

    // 商品ページURL
    private String selfLink;

    // 評価
    private int fun;

    // コメント
    private String summary;

    // 既読未読、初期値未読
    private boolean alreadyRead = false;

    // 持ってるか買ってるか
    private int have;

    // description商品説明
    private String description;

    // コンストラクタ
    public Book(String id, String title, String publisher, String authors, String thumbnail, String identifier,
            String selfLink, String description, int fun, String summary, boolean alreadyRead, int have) {
        this.id = id;
        this.title = title;
        this.publisher = publisher;
        this.authors = authors;
        this.thumbnail = thumbnail;
        this.identifier = identifier;
        this.selfLink = selfLink;
        this.fun = fun;
        this.summary = summary;
        this.alreadyRead = alreadyRead;
        this.have = have;
        this.description = description;
    }

    // public String getAuthors() {
    // return authors;
    // }

    // public void setAuthors(String authors) {
    // this.authors = authors;
    // }

    public Book() {
        // TODO 自動生成されたコンストラクター・スタブ
    }

    public String getAuthors() {
        return authors;
    }

    public void setAuthors(String authors) {
        this.authors = authors;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getSelfLink() {
        return selfLink;
    }

    public void setSelfLink(String selfLink) {
        this.selfLink = selfLink;
    }

    public int getFun() {
        return fun;
    }

    public void setFun(int fun) {
        this.fun = fun;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public boolean isAlreadyRead() {
        return alreadyRead;
    }

    public void setAlreadyRead(boolean alreadyRead) {
        this.alreadyRead = alreadyRead;
    }

    public int getHave() {
        return have;
    }

    public void setHave(int have) {
        this.have = have;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String booktitle) {
        this.title = booktitle;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

}